﻿
namespace HASTANEPROJE
{
    partial class form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gncbtn = new System.Windows.Forms.Button();
            this.listbtn = new System.Windows.Forms.Button();
            this.eklebtn = new System.Windows.Forms.Button();
            this.silbtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.arabtn = new System.Windows.Forms.Button();
            this.hodatxt = new System.Windows.Forms.TextBox();
            this.hadtxt = new System.Windows.Forms.TextBox();
            this.tctxt = new System.Windows.Forms.TextBox();
            this.hyastxt = new System.Windows.Forms.TextBox();
            this.hsoyadtxt = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.cksbtn = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.cintxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // gncbtn
            // 
            this.gncbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.gncbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.gncbtn.Location = new System.Drawing.Point(793, 140);
            this.gncbtn.Name = "gncbtn";
            this.gncbtn.Size = new System.Drawing.Size(75, 23);
            this.gncbtn.TabIndex = 4;
            this.gncbtn.Text = "GÜNCELLE";
            this.gncbtn.UseVisualStyleBackColor = false;
            // 
            // listbtn
            // 
            this.listbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.listbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.listbtn.Location = new System.Drawing.Point(793, 15);
            this.listbtn.Name = "listbtn";
            this.listbtn.Size = new System.Drawing.Size(75, 23);
            this.listbtn.TabIndex = 1;
            this.listbtn.Text = "LİSTELE";
            this.listbtn.UseVisualStyleBackColor = false;
            this.listbtn.Click += new System.EventHandler(this.listbtn_Click);
            // 
            // eklebtn
            // 
            this.eklebtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.eklebtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.eklebtn.Location = new System.Drawing.Point(793, 56);
            this.eklebtn.Name = "eklebtn";
            this.eklebtn.Size = new System.Drawing.Size(75, 23);
            this.eklebtn.TabIndex = 2;
            this.eklebtn.Text = "EKLE";
            this.eklebtn.UseVisualStyleBackColor = false;
            this.eklebtn.Click += new System.EventHandler(this.eklebtn_Click);
            // 
            // silbtn
            // 
            this.silbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.silbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.silbtn.Location = new System.Drawing.Point(793, 97);
            this.silbtn.Name = "silbtn";
            this.silbtn.Size = new System.Drawing.Size(75, 23);
            this.silbtn.TabIndex = 3;
            this.silbtn.Text = "SİL";
            this.silbtn.UseVisualStyleBackColor = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(548, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "HASTA SOYADI:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(573, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "HASTA TC:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(573, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "HASTA ADI:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(584, 178);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 13);
            this.label4.TabIndex = 9;
            this.label4.Text = "ODA NO:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(563, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 10;
            this.label5.Text = "HASTA YAŞI:";
            // 
            // arabtn
            // 
            this.arabtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.arabtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.arabtn.Location = new System.Drawing.Point(793, 178);
            this.arabtn.Name = "arabtn";
            this.arabtn.Size = new System.Drawing.Size(75, 23);
            this.arabtn.TabIndex = 5;
            this.arabtn.Text = "ARA";
            this.arabtn.UseVisualStyleBackColor = false;
            // 
            // hodatxt
            // 
            this.hodatxt.Location = new System.Drawing.Point(658, 175);
            this.hodatxt.Name = "hodatxt";
            this.hodatxt.Size = new System.Drawing.Size(100, 20);
            this.hodatxt.TabIndex = 15;
            // 
            // hadtxt
            // 
            this.hadtxt.Location = new System.Drawing.Point(658, 56);
            this.hadtxt.Name = "hadtxt";
            this.hadtxt.Size = new System.Drawing.Size(100, 20);
            this.hadtxt.TabIndex = 11;
            // 
            // tctxt
            // 
            this.tctxt.Location = new System.Drawing.Point(658, 12);
            this.tctxt.Name = "tctxt";
            this.tctxt.Size = new System.Drawing.Size(100, 20);
            this.tctxt.TabIndex = 12;
            // 
            // hyastxt
            // 
            this.hyastxt.Location = new System.Drawing.Point(658, 133);
            this.hyastxt.Name = "hyastxt";
            this.hyastxt.Size = new System.Drawing.Size(100, 20);
            this.hyastxt.TabIndex = 13;
            // 
            // hsoyadtxt
            // 
            this.hsoyadtxt.Location = new System.Drawing.Point(658, 97);
            this.hsoyadtxt.Name = "hsoyadtxt";
            this.hsoyadtxt.Size = new System.Drawing.Size(100, 20);
            this.hsoyadtxt.TabIndex = 14;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(524, 245);
            this.dataGridView1.TabIndex = 0;
            // 
            // cksbtn
            // 
            this.cksbtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(177)))), ((int)(((byte)(140)))));
            this.cksbtn.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.cksbtn.Location = new System.Drawing.Point(793, 249);
            this.cksbtn.Name = "cksbtn";
            this.cksbtn.Size = new System.Drawing.Size(75, 23);
            this.cksbtn.TabIndex = 16;
            this.cksbtn.Text = "ÇIKIŞ";
            this.cksbtn.UseVisualStyleBackColor = false;
            this.cksbtn.Click += new System.EventHandler(this.cksbtn_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(578, 216);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(59, 13);
            this.label6.TabIndex = 17;
            this.label6.Text = "CİNSİYET:";
            // 
            // cintxt
            // 
            this.cintxt.Location = new System.Drawing.Point(658, 216);
            this.cintxt.Name = "cintxt";
            this.cintxt.Size = new System.Drawing.Size(100, 20);
            this.cintxt.TabIndex = 18;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(577, 249);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 13);
            this.label7.TabIndex = 19;
            this.label7.Text = "İLAÇ İSMİ";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(658, 249);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(100, 21);
            this.comboBox1.TabIndex = 20;
            // 
            // form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(894, 284);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.cintxt);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.cksbtn);
            this.Controls.Add(this.hodatxt);
            this.Controls.Add(this.hsoyadtxt);
            this.Controls.Add(this.hyastxt);
            this.Controls.Add(this.tctxt);
            this.Controls.Add(this.hadtxt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.arabtn);
            this.Controls.Add(this.gncbtn);
            this.Controls.Add(this.silbtn);
            this.Controls.Add(this.eklebtn);
            this.Controls.Add(this.listbtn);
            this.Controls.Add(this.dataGridView1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form2";
            this.Text = "MEDİKAL_PALACE_HASTANESI";
            this.Load += new System.EventHandler(this.form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button gncbtn;
        private System.Windows.Forms.Button listbtn;
        private System.Windows.Forms.Button eklebtn;
        private System.Windows.Forms.Button silbtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button arabtn;
        private System.Windows.Forms.TextBox hodatxt;
        private System.Windows.Forms.TextBox hadtxt;
        private System.Windows.Forms.TextBox tctxt;
        private System.Windows.Forms.TextBox hyastxt;
        private System.Windows.Forms.TextBox hsoyadtxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button cksbtn;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox cintxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}