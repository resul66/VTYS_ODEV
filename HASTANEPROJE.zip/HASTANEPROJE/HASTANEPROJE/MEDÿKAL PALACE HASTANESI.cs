﻿using Npgsql;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HASTANEPROJE
{
    public partial class form2 : Form
    {
        public form2()
        {
            InitializeComponent();
        }

        NpgsqlConnection baglanti = new NpgsqlConnection("Server=localhost;" +
                                                      "Port=5432;" +
                                                      "User Id=postgres;" +
                                                      "Password=159753;" +
                                                      "Database=Hastane;");
        private void listbtn_Click(object sender, EventArgs e)
        {
            string sorgu = "select * from public.hasta";
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(sorgu,baglanti);
            DataSet ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
           

        }

        private void eklebtn_Click(object sender, EventArgs e)
        {
            baglanti.Open();
            NpgsqlCommand komut1 = new NpgsqlCommand("insert into hasta(hasta_tc,hasta_adi,hasta_soyadi,yas,oda_no,hasta_cinsiyeti,ilac_ismi) values(@p1,@p2,@p3,@p4,@p5,@p6,@p7)", baglanti);
            komut1.Parameters.AddWithValue("@p1", tctxt.Text);
            komut1.Parameters.AddWithValue("@p2", hadtxt.Text); 
            komut1.Parameters.AddWithValue("@p3", hsoyadtxt.Text);
            komut1.Parameters.AddWithValue("@p4", hyastxt.Text);
            komut1.Parameters.AddWithValue("@p5", hodatxt.Text);
            komut1.Parameters.AddWithValue("@p6", cintxt.Text);
            komut1.Parameters.AddWithValue("@p7", comboBox1.SelectedItem);
            komut1.ExecuteNonQuery();


            baglanti.Close();
            MessageBox.Show("Kategori Ekleme İşlemi Başarılı Bir Şekilde Gerçekleşti.");
        }

        private void cksbtn_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void form2_Load(object sender, EventArgs e)
        {

            baglanti.Open();
            NpgsqlDataAdapter dr = new NpgsqlDataAdapter("select * from public.recete",baglanti);
            DataTable dt = new DataTable();
            dr.Fill(dt);
            comboBox1.DisplayMember = "ilac_ismi";
            comboBox1.DataSource = dt;
            baglanti.Close();
        }
    }
}
